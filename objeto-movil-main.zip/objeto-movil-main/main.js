import { Tablero } from './controladores/tablero.controlador.js'

const TABLERO = new Tablero();