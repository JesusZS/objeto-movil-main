# Introducción
Este proyecto trata de un objeto móvil deslizante sobre el eje X que puede ser controlado con unos simples botones. Este proyecto está diseñado totalmente con POO para una excelente modularidad entre los objetos visuales.

# Links
Puedes ver el desarrollo de las clase UML al dar click en el siguiente link: [Ver diagrama de lucid.](https://lucid.app/lucidchart/c917f3da-95ab-4a51-8af0-d4c82b51c594/edit?invitationId=inv_175e8232-c655-464f-b63e-626d4d1bc07b)